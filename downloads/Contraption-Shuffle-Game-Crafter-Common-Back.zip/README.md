# The Contraption Shuffle · The Game Crafter edition

One 54-card poker deck with a common, reversible back and a custom printed tuckbox. The faces include 18 green Materials cards (stacked sheets), 18 blue Mechanism cards (gear), and 18 red Mission cards (flag). The rules are printed on the box and included as a separate PDF.

## Upload the game

Unzip this pack. If the back upload field asks for **750 × 1125 pixels**, choose `back/common-back.png`. For the **Poker Deck** component, use the 825 × 1125 back with the matching 54 poker faces. Upload one back for the entire deck.

| Component or field | File or folder | What to do |
| --- | --- | --- |
| Deck Back field requesting 750 × 1125 | `back/common-back.png` | Upload this reversible common back. |
| Poker Deck → Back (825 × 1125) | `poker/back-825x1125.png` | Use with the poker faces in this pack. |
| Poker Deck → Card faces | `faces/` | Select the 54 PNGs together. Use one copy of each face. The M, K, and G filenames identify the three categories. |
| Poker Tuck Box (54 cards) → Outside artwork | `box/poker-tuckbox-54.png` | Add one 54-card Poker Tuck Box. Upload the full image at its supplied dimensions. |
| Player rules | `rules/Contraption-Shuffle-Common-Back-Rules.pdf` | Share or print the one-page rules separately. The box gives directions for both ways to draw. |

Use **Proof All** to review the deck, then proof the box in its component editor. Check the deck count is **54**, the back is the same on every card, and the tuckbox title and directions sit inside the fold guides. Order a single proof copy to check physical color, cut, fold and fit.

## Artwork dimensions

| Artwork | Pixels | Finished component |
| --- | --- | --- |
| Common back | 750 × 1125 | For a deck back field specifying this pixel size |
| Poker faces and Poker Deck back | 825 × 1125 | 2.5 × 3.5 inch poker card with 0.125 inch bleed on each edge |
| Tuckbox outside | 2325 × 1950 | The Game Crafter's Poker Tuck Box (54 cards) |

The production PNGs are RGB at 300 ppi. Bleed is included, and template guides are excluded. The ZIP and PDF are for distribution. Use the individual PNGs in the print component editor.

## Play

**Three piles.** Sort by the labels on the faces. Shuffle each pile, turn it face down, and keep the order Materials, Mechanism, Mission. Draw one from each.

**One shuffled deck.** Shuffle all 54 cards. Reveal cards until you have one of each category. Keep the first of each and set aside the duplicates. Return all revealed cards and shuffle before the next round.

Use the material as a main ingredient and make the mechanism help accomplish the mission. A working model counts.

[Card upload walkthrough](https://help.thegamecrafter.com/article/399-how-to-make-a-card-game-tarot-deck) · [Poker Deck](https://www.thegamecrafter.com/make/products/PokerDeck) · [54-card tuckbox template](https://www.thegamecrafter.com/make/products/PokerTuckBox54)

A workshop game by Michael B. Parks · [michaelbparks.com](https://michaelbparks.com/)
